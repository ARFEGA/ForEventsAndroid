package net.forevents.foreventsandroid.Data.CreateUser.User




data class TokenUserApiResponse(
        val results : ApiUser
)
