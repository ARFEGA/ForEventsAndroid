package net.forevents.foreventsandroid.presentation.UserList


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_events.*
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.presentation.Navigator.Navigator
import net.forevents.foreventsandroid.BuildConfig
import net.forevents.foreventsandroid.R
import net.forevents.foreventsandroid.Util.ShowAlert

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit

class UserListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_events)

        button.setOnClickListener {
            //mostrarAlert()
            observerLiga()
        }
        setUpRecycler()
        setUpViewModel()

    }
    lateinit var userListViewModel: UserListVM

    private val adapter =
        RecyclerAdapter { onUserClick(it) }

    private fun onUserClick(userEntity: UserEntity){
        //val intent=Intent(this,UserDetailActivity::class.java)
        //intent.putExtra(UserDetailActivity.PARAM_USER_ENTITY,userEntity.userId)
        //startActivity(intent)
        //Las líneas anteriores, las sustituimos, por la llamada a un singleton
        Navigator.OpenUserDetail(this,userEntity)


    }
    private fun setUpRecycler(){
        recycler_view.layoutManager = LinearLayoutManager(this,RecyclerView.VERTICAL,false)
        recycler_view.itemAnimator = DefaultItemAnimator()
        recycler_view.adapter = adapter
    }

    private  fun setUpViewModel(){
        userListViewModel = ViewModelProviders.of(this).get(UserListVM::class.java)
        bindEvents()
        //userListViewModel.loadUserList()
    }

    private fun bindEvents(){
        userListViewModel.isLoadingState.observe(this, Observer { isLoading ->
            isLoading?.let{
                user_list_loading.visibility = if(it)  View.VISIBLE else View.GONE
            }
        })

        userListViewModel.userListState.observe(this, Observer { userList ->
            userList?.let{
                onUserListLoaded(it)
            }
        })
    }
    private fun onUserListLoaded(userList:List<UserEntity>){
        adapter.submitList(userList)
    }

    override fun onResume() {
        super.onResume()
        userListViewModel.loadUserList()
    }


    data class Liga(val nameLiga:String)

    val ligas = listOf(
        Liga("Española"),
        Liga("Inglesa")
    )
    data class Equipo(val nameEquipo:String , val liga: Liga)

    val equipos = listOf(
        Equipo("ATM", ligas[0]),
        Equipo("Chelsea", ligas[1])
    )
    data class Jugador(val nameJugador:String,val equipo: Equipo)

    val jugadores = listOf(
        Jugador("Koke", equipos[0]),
        Jugador("Morata", equipos[1])
    )

    fun observerLiga(){
        val observable = Observable.just(jugadores)
        observable
            .flatMap {
                Observable.just(it.first().equipo)}
            .flatMap {Observable.just(it.liga)}
            .subscribe { println(it) }
    }



    fun mostrarAlert(){
        val disposable = CompositeDisposable()
        println("xx1 Main: ${Thread.currentThread().id}")
        val observable = Observable.create<Int> {o ->
            println("xx1 Created on :${Thread.currentThread().id}")
            o.onNext(1)
            o.onNext(2)
            o.onNext(3)
            o.onNext(4)
            o.onNext(5)
            o.onNext(6)
            o.onComplete()
        }
            .subscribeOn(Schedulers.newThread())
            .observeOn(Schedulers.io())
            .filter{it % 2 == 0}
            //.take(1)
            .map { it * 2 }
            .subscribe ({i-> println("xx1 Received ${i} in ${Thread.currentThread().id}")  })


        println("xx1 Main: ${Thread.currentThread().id}")

        ShowAlert(this,"4Events", BuildConfig.URL_API)
    }

    fun provideOkhttpClient():OkHttpClient=
            OkHttpClient.Builder()
                .addInterceptor(HttpLoggingInterceptor().apply {
                    level=HttpLoggingInterceptor.Level.BODY
                })
                .build()
    fun provideRetrofit(okHttpClient: OkHttpClient):Retrofit=
            Retrofit.Builder()
                .baseUrl(BuildConfig.URL_API)
                .client(okHttpClient)
                .build()
}
