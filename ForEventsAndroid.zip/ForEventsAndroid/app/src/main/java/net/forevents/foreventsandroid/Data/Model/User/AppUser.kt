package net.forevents.foreventsandroid.Data.CreateUser.User

import java.io.Serializable

data class AppUser(val ok:String,val token:String,val profile:String,val email:String,val password:String):Serializable