package net.forevents.foreventsandroid.Data.CreateUser.User

import com.google.gson.annotations.SerializedName

class ApiUser(
    @SerializedName("ok") val ok:String,
    @SerializedName("token") val token : String,
    @SerializedName("user") val user:User)



class User(
    @SerializedName("password") val password:String,
    @SerializedName("profile") val profile : String,
    @SerializedName("email") val email:String
)