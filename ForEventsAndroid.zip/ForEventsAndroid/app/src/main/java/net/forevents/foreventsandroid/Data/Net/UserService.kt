package net.forevents.foreventsandroid.Data.Net



import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.Single
import net.forevents.foreventsandroid.Data.CreateUser.CreateUser.CreateUserApiResponse
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserApiResponse
import net.forevents.foreventsandroid.Data.CreateUser.User.TokenUserApiResponse

import retrofit2.http.*

interface UserService {
    @GET("api/?results=20")
    fun getUsers(): Flowable<UserApiResponse>


    //@Headers("Content-Type: application/x-www-form-urlencoded")

    @FormUrlEncoded
    @POST("users/login")
    fun loginUser(@Field("email") email: String,
                  @Field("password") password: String):Observable<TokenUserApiResponse>


    @FormUrlEncoded
    @POST("users/login")
    fun getUserTokenPrueba(@Field("email") email: String,
                           @Field("password") password: String):Observable<String>




    @POST("users/login")
    fun loginUser__(@Query("email") email: String,
                  @Query("password") password: String):Single<TokenUserApiResponse>

    @POST("users/login")
    fun loginUser_(@Body email:String):Observable<TokenUserApiResponse>


    @FormUrlEncoded
    @POST("users/register")
    fun createUser(@Field("email") email: String,
                   @Field("password") password: String,
                   @Field("first_name") first_name:String,
                   @Field("last_name") last_name:String)    : Single<CreateUserApiResponse>
}