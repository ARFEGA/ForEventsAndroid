package net.forevents.foreventsandroid.presentation.SingUpLogin

import android.os.Bundle

import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.activity_login.*
import net.forevents.foreventsandroid.presentation.Navigator.Navigator
import net.forevents.foreventsandroid.presentation.servicelocator.Inject.repository
import net.forevents.foreventsandroid.R
import net.forevents.foreventsandroid.Util.showDialog


class LoginActivity : AppCompatActivity() {

    companion object {
        val EXTRA_LOGIN_USER = "LOGIN_USER"
    }


    val alias:String?
    get()= intent.getStringExtra(EXTRA_LOGIN_USER)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Log.v("EXTRA","fregrewgerwre")

        btn_login.setOnClickListener {
            repository.getUserTokenPrueba()
            Navigator.OpenListEvents(this)}
        setUpViewModel()

        //init()
    }
    lateinit var userViewModel: UserVM

    private fun setUpViewModel(){
        userViewModel = ViewModelProviders.of(this).get(UserVM::class.java)
        BindEvents()
    }
    fun BindEvents(){
        userViewModel.userState.observe(this, Observer {dataUser ->
            dataUser?.let {
                showDialog(this,"Datos desde API","El Token: ${it.token}")
            }
        })
    }

    fun init()  {
        //ShowAlert(this,"4Events",alias)
        alias?.let{
            Log.v("EXTRA",alias)
            text_user.setText(it)
            text_pasw.requestFocus()
            showDialog(this,"4Events","Bienvenido ${alias}")
        }

    }

    override fun onResume() {
        super.onResume()
        userViewModel.loadUser()
    }

}
