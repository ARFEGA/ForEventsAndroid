package net.forevents.foreventsandroid.Data.CreateUser.User

data class AppCreateUser(val ok:Boolean,
                         val message:String,
                         val email:String,
                         val password:String,
                         val first_name:String,
                         val last_name:String?,
                         val create_date:String?,
                         val delete_date:String?)