package net.forevents.foreventsandroid.Data.Repository.DataSource


import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.Single
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.Data.CreateUser.User.AppCreateUser
import net.forevents.foreventsandroid.Data.CreateUser.User.AppUser


interface DataSource {

    fun getUserList() :Flowable<List<UserEntity>>
    fun getUserToken(): Observable<AppUser>
    fun getUserTokenPrueba()
    fun createUser():Single<AppCreateUser>
    /*fun getUserdetail(userId:Long):Observable<UserEntity>*/

}