package net.forevents.foreventsandroid.Data.CreateUser.Event

data class EventEntity(val name:String)

/*
* Media_types__id INT
Indexes
_id INT
name CHAR(50)
description CHAR(100)
url CHAR(100)
Events__id INT
Users__id INT
Indexes



Media
_id INT
begin_date DATE
end_date DATE
begin_time TIME
end_time TIME
latitude FLOAT
longitude FLOAT
address CHAR(100)
city CHAR(100)
zip_code CHAR(10)
province CHAR(100)
country CHAR(100)
indoor TINYINT
max_visitors INT
free TINYINT
price DECIMAL(15)
create_date DATE
create_time TIME
min_age INT
name CHAR(50)
description TEXT(1000)
Events_types__id INT
EventEntity
Users__id INT
Indexes
name CHAR(25)
Indexes
_id INT
create_date DATE
create_time TIME
Events__id INT
_id INT
Transactions
name CHAR(25)
Indexes
Events_types
_id INT
Media_types
phone_number CHAR(25)
Indexes
_id INT
first_name CHAR(25)
last_name CHAR(100)
email CHAR(100)
address CHAR(100)
city CHAR(100)
zip_code CHAR(10)
province CHAR(100)
country CHAR(100)
password CHAR(50)
birthdate DATE
gender CHAR(25)
create_date DATE
delete_date DATE
alias CHAR(50)
Profile__id INT
Cities__id INT
idn CHAR(25)
company_name CHAR(100)
mobile_number CHAR(25)
latitude FLOAT
Indexes
Users
_id INT
city CHAR(100)
province CHAR(100)
country CHAR(50)
longitude FLOAT
Cities
Events_types__id INT
Indexes
_id INT
create_date DATE
query CHAR(100)
Users__id INT
Favorite_searches
description CHAR(50)
Indexes
_id INT
Profile

* */