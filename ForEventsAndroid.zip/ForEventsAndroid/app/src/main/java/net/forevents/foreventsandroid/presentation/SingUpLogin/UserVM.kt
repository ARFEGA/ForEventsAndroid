package net.forevents.foreventsandroid.presentation.SingUpLogin


import androidx.lifecycle.MutableLiveData

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.addTo
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import net.forevents.foreventsandroid.Data.CreateUser.User.AppCreateUser
import net.forevents.foreventsandroid.Data.CreateUser.User.AppUser
import net.forevents.foreventsandroid.presentation.servicelocator.Inject
import net.forevents.foreventsandroid.Util.mvvm.BaseViewModel


class UserVM: BaseViewModel() {
    val userState : MutableLiveData<AppUser> = MutableLiveData()
    val createUserState : MutableLiveData<AppCreateUser> = MutableLiveData()

    fun loadUser(){
        Inject.repository.getUserToken()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
           .subscribeBy (
               onNext = {
                   println(it.token)
                   userState.value = it
               },
               onError = {
                    println("########ERROR ON LOGIN ########### ${it.message}")
               }
               /* onNext = {
                    userState.value = it
                },
                onError = {

                },
                onComplete = {

                }*/
            ).addTo(compositeDisposable)
    }

    fun createUser(){
        Inject.repository.createUser()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .subscribeBy(
                onSuccess = {
                    createUserState.value=it
                },
                onError = {
                    println("######## ERROR on CREATE ########### ${it.message}")
                }
            ).addTo(compositeDisposable)
    }
}