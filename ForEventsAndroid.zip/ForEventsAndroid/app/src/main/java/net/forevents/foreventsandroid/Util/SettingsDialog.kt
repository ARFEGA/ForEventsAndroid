package net.forevents.foreventsandroid.Util


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import kotlinx.android.synthetic.main.dialog_fragment_settings.*
import net.forevents.foreventsandroid.R


class SettingsDialog: DialogFragment() {
    companion object {
        val ARG_UNITS = "ARG_UNITS"
        fun newIntance(initialUnits:String):SettingsDialog{
            val arguments = Bundle()
            arguments.putString(ARG_UNITS,initialUnits)
            val dialog = SettingsDialog()
            dialog.arguments=arguments
            return dialog
        }
    }

    val initialUnits by lazy {
        arguments?.getString(ARG_UNITS)
    }

    fun setActualUnits(){
        when(initialUnits){
            "A"->radio_group.check(R.id.radio_1)
            "B"->radio_group.check(R.id.radio_2)
            else -> radio_group.check(R.id.radio_1)
        }
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.dialog_fragment_settings,container,false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setActualUnits()
        cancel_settings.setOnClickListener {
            cancelSettings()
        }

        accept_settings.setOnClickListener {
            acceptSettings()
        }

        //Hacemos la animación del radio_group
        radio_group.visibility = View.GONE
        radio_group.postDelayed({
            radio_group.visibility = View.VISIBLE
        },500)

        super.onViewCreated(view, savedInstanceState)
    }

    private fun acceptSettings() {
        val selectedUnits: String = when{
            radio_group.checkedRadioButtonId == R.id.radio_1 -> "A"
            else -> "B"
        }
        val returnIntent= Intent()
        returnIntent.putExtra(ARG_UNITS,selectedUnits)
        //Al igual que con el cancel, el ok/accept es distinto en DialogFragment
        targetFragment?.onActivityResult(targetRequestCode, Activity.RESULT_OK,returnIntent)
        //Cerramos ventana
        dismiss()


    }

    private fun cancelSettings() {
        //En un DialogFragment, las coss son distintas
        //Le decimos a quien nos ha llamado (targetFragment),
        //que el resultado (onActivityResult) es cancel
        targetFragment?.onActivityResult(targetRequestCode, Activity.RESULT_CANCELED,null)
        //Cerramos la ventana
        dismiss()
    }

}