package net.forevents.foreventsandroid.presentation.Navigator

import android.app.Activity
import android.content.Intent
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.presentation.SingUpLogin.LoginActivity
import net.forevents.foreventsandroid.presentation.UserDetail.UserDetailActivity
import net.forevents.foreventsandroid.presentation.UserList.UserListActivity


object Navigator {

    fun OpenUserDetail(activityOrigin:Activity, userEntity: UserEntity){
        val intent = Intent(activityOrigin,
            UserDetailActivity::class.java)
        intent.putExtra(UserDetailActivity.PARAM_USER_ENTITY,userEntity)
        activityOrigin.startActivity(intent)
    }

    fun OpenLogin(activityOrigin:Activity, alias: String){
        val intent = Intent(activityOrigin,
            LoginActivity::class.java)
        intent.putExtra(LoginActivity.EXTRA_LOGIN_USER,alias)
        activityOrigin.startActivity(intent)
    }
    fun OpenListEvents(activityOrigin:Activity){
        val intent = Intent(activityOrigin,
            UserListActivity::class.java)
        activityOrigin.startActivity(intent)
    }

}