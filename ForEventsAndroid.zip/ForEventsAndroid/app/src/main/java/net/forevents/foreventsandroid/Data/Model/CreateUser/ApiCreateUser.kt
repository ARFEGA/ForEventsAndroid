package net.forevents.foreventsandroid.Data.CreateUser.User

import com.google.gson.annotations.SerializedName

data class ApiCreateUser(
    @SerializedName("ok") val ok:Boolean,
    @SerializedName("message") val message : String,
    @SerializedName("user") val user:CreateUser)



data class CreateUser(
    @SerializedName("email") val email:String,
    @SerializedName("password") val password : String,
    @SerializedName("first_name") val first_name:String,
    @SerializedName("last_name") val last_name:String,
    @SerializedName("create_date") val create_date : String?,
    @SerializedName("delete_date") val delete_date:String?
)