package net.forevents.foreventsandroid.Data.CreateUser.CreateUser

import net.forevents.foreventsandroid.Data.CreateUser.User.ApiCreateUser


data class CreateUserApiResponse (
    val results : ApiCreateUser
)

