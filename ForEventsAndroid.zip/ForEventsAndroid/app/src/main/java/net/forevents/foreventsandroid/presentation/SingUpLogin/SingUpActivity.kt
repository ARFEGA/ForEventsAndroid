package net.forevents.foreventsandroid.presentation.SingUpLogin

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders

import kotlinx.android.synthetic.main.activity_sing_up.*

import net.forevents.foreventsandroid.R
import net.forevents.foreventsandroid.Util.showDialog


class SingUpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sing_up)

        btn_sing_up.setOnClickListener {

            //todo Asegurar la información necesaria
            //todo registrar user en api
            //todo notificar el resultado del alta y pasar a pantalla de login si el alta ha sido satisfactoria
            if(true){
                userViewModel.createUser()
                //todo pasar parametro alias a la pantalla login par que el user no tenga que introducirlo y situarle en pws
                //Navigator.OpenLogin(this,alias_text.text.toString())
            }else{
                setResult(Activity.RESULT_CANCELED)
                finish()
            }

        }
        setupViewModel()

    }
    lateinit var userViewModel : UserVM

    private fun setupViewModel(){
        userViewModel = ViewModelProviders.of(this).get(UserVM::class.java)
        BindEvents()
    }
    private fun BindEvents(){
        userViewModel.createUserState.observe(this, Observer {userCreated->
            userCreated?.let {
                showDialog(this,"'CREATE' Datos desde API ","El EMAIL: ${it.email}")
            }
        })
    }
}
