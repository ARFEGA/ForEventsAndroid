package net.forevents.foreventsandroid.Data.CreateUser.RandomUser




data class UserApiResponse (
    val results : List<RandomUser>
)

