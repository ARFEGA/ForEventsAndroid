package net.forevents.foreventsandroid.presentation.UserDetail

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Criteria
import android.location.LocationManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProviders

import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_user_detail.*


import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.R
import net.forevents.foreventsandroid.Util.showDialog


class UserDetailActivity : AppCompatActivity() ,OnMapReadyCallback,  GoogleMap.OnMarkerClickListener{
    companion object {
        private const val MY_LOCATION_REQUEST_CODE = 329
        private const val NEW_REMINDER_REQUEST_CODE = 330
        private const val EXTRA_LAT_LNG = "EXTRA_LAT_LNG"
        val PARAM_USER_ENTITY = "PARAM_USER_ENTITY"

    }

    private var map: GoogleMap? = null

    private lateinit var locationManager: LocationManager

    var userEntity: UserEntity? = null

    //1º Preparamos la variable que apunta al ViewModel
    lateinit var userDetailVM: UserDetailVM
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_detail)

        //val toolbar = findViewById(R.id.toolbar) as Toolbar
        //setSupportActionBar(toolbar)


        userEntity = intent.getParcelableExtra(PARAM_USER_ENTITY)
        initMap()
        init()
    }
    //Pertenece a OnMapReadyCallback
    override fun onMapReady(gooleMap: GoogleMap?) {
        map = gooleMap
        map?.run{
            uiSettings.isMyLocationButtonEnabled = true
            uiSettings.isMapToolbarEnabled  = true
            setOnMarkerClickListener(this@UserDetailActivity)
        }
        onMapAndPermissionReady()
    }

    //Pertenece a GoogleMap.OnMarkerClickListener
    override fun onMarkerClick(p0: Marker?): Boolean {
        showDialog(this,"Desde el mapa","Desde el mapa")
        return true
    }

    private fun initMap(){
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapView) as SupportMapFragment
        mapFragment.getMapAsync(this)

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), MY_LOCATION_REQUEST_CODE)
        }

    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == MY_LOCATION_REQUEST_CODE){
            onMapAndPermissionReady()
        }
    }



    private fun onMapAndPermissionReady(){
        if (map != null && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED){
            map?.isMyLocationEnabled = true
            val bestProvider = locationManager.getBestProvider(Criteria(), false)
            val location = locationManager.getLastKnownLocation(bestProvider)
            if (location != null) {
                val latLng = LatLng(location.latitude, location.longitude)
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
            }
            centerCamera(LatLng(40.370038,-3.468868))
        }
    }
    private fun centerCamera(latLon:LatLng){
        map?.moveCamera(CameraUpdateFactory.newLatLngZoom(latLon,15f))
    }


    private fun init(){
        //2º Inicializamos la variable que apunta al ViewModel de esta activity
        userDetailVM = ViewModelProviders.of(this).get(UserDetailVM::class.java)
        //3º Hacemos el bindEvents del ViewModel
        //bindEvents()
        //4º
        loadUserData()
    }

    /*private fun bindEvents(){
        userDetailVM.userState.observe(this, Observer {userEntity ->
            userEntity?.let{
                onUserLoaded(it)
            }

        })
    }*/
    private fun loadUserData(){
        //Comprobamos si tenemos v alor de usuario
        if(userEntity == null){
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
        //Llamamos a la función de lViewModel
        //userDetailVM.loadUserById(user_id)
        onUserLoaded(userEntity!!)
    }
    private fun onUserLoaded(userEntity: UserEntity){
        //Asignamos first_name a la caja de texto
        name_user_text.text = userEntity.first_name
        //Mediante Glide, asignamos la imagen al objeto image
        Glide.with(this)
            .load(userEntity.picture)
            .into(image_user)

    }



}