package net.forevents.foreventsandroid.presentation.servicelocator


import net.forevents.foreventsandroid.Data.CreateUser.CreateUser.OutAppCreateUserMapper
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.OutUserEntityMapper
import net.forevents.foreventsandroid.Data.CreateUser.User.OutAppUserMapper
import net.forevents.foreventsandroid.Data.Net.UserService
import net.forevents.foreventsandroid.Data.Repository.Repository
import net.forevents.foreventsandroid.Util.SettingsManager
import net.forevents.foreventsandroid.BuildConfig
import net.forevents.foreventsandroid.Data.Repository.DataSource.ApiDataSource
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory


object Inject {

    lateinit var settingsManager : SettingsManager



    //Conexión api
    val retrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.URL_API)
        //.baseUrl("https://randomuser.me/")
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .build()
    val userService = retrofit.create(UserService::class.java)
    //Fin conexión api
   val outUserEntityMapper = OutUserEntityMapper()
    val outAppUserMapper = OutAppUserMapper()
    val outAppCreateUserMapper =
        OutAppCreateUserMapper()
    private val apiDataSource = ApiDataSource(
        userService,
        outUserEntityMapper,
        outAppUserMapper,
        outAppCreateUserMapper
    )
    val repository = Repository(apiDataSource)

    //private val fakeDataSource : FakeDataSource = FakeDataSource()
//    private val fakeDataSource2 : FakeDataSource2 = FakeDataSource2()
//    val repository: Repository = Repository(fakeDataSource, fakeDataSource2)
}