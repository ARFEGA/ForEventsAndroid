package net.forevents.foreventsandroid.Data.Repository



import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.Single
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.Data.CreateUser.User.AppCreateUser
import net.forevents.foreventsandroid.Data.CreateUser.User.AppUser
import net.forevents.foreventsandroid.Data.Repository.DataSource.ApiDataSource


class Repository(private val apiDataSource: ApiDataSource) {
     fun getUserList():Flowable<List<UserEntity>> =
             apiDataSource.getUserList()


    fun getUserToken(): Observable<AppUser> = apiDataSource.getUserToken()

    fun getUserTokenPrueba(){
        apiDataSource.getUserTokenPrueba()
    }

    fun createUser():Single<AppCreateUser> = apiDataSource.createUser()




     /*fun getUserList(): Flowable<List<UserEntity>> =
          fakeDataSource.getUserList()
          .zipWith(fakeDataSource2.getUserList())
          .map { pair ->
               val newList = mutableListOf<UserEntity>()
               newList.addAll(pair.first)
               newList.addAll(pair.second)
               newList.toList()
          }
          .delay(1,TimeUnit.SECONDS)*/

   /*  fun getUserdetail(userId: Long): Observable<UserEntity> =
          fakeDataSource.getUserdetail(userId)
               //.onErrorResumeNext { _: Throwable -> fakeDataSource2.getUserdetail(userId) }
               .switchIfEmpty(fakeDataSource2.getUserdetail(userId))
               .delay(1,TimeUnit.SECONDS)
*/



}