package net.forevents.foreventsandroid.presentation.UserList

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.row_item.view.*


import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntityDiff
import net.forevents.foreventsandroid.R

typealias OnUserClick = (userEntity: UserEntity) -> Unit

class RecyclerAdapter(val onUserClick : OnUserClick): ListAdapter<UserEntity,RecyclerAdapter.AdapterViewHolder>(
    UserEntityDiff()
) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdapterViewHolder {
        val row = LayoutInflater.from(parent.context).inflate(R.layout.row_item,parent,false)
        return AdapterViewHolder(row)
    }

    override fun onBindViewHolder(holder: AdapterViewHolder, position: Int) {
        holder.bind(getItem(position))
    }


    inner class AdapterViewHolder(view: View) :RecyclerView.ViewHolder(view){

        fun bind(userEntity: UserEntity){
            with(itemView){//itemView es una propiedad que apunta a cada una de las filas
                user_name.text = userEntity.first_name
                Glide.with(image_view)
                    .load(userEntity.picture)
                    .into(image_view)

            }
            //Asignación del evento click a la fila
            itemView.setOnClickListener {
                //onUserClick(getItem(adapterPosition)) Esta o la siguiente opción
                onUserClick(userEntity)
            }
        }
    }



}