package net.forevents.foreventsandroid.Data.Repository.DataSource



import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.Single


import net.forevents.foreventsandroid.Data.CreateUser.CreateUser.OutAppCreateUserMapper
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.OutUserEntityMapper
import net.forevents.foreventsandroid.Data.CreateUser.RandomUser.UserEntity
import net.forevents.foreventsandroid.Data.CreateUser.User.AppCreateUser
import net.forevents.foreventsandroid.Data.CreateUser.User.AppUser
import net.forevents.foreventsandroid.Data.CreateUser.User.OutAppUserMapper
import net.forevents.foreventsandroid.Data.Net.UserService
import net.forevents.foreventsandroid.presentation.servicelocator.Inject
import java.io.Serializable
import java.util.concurrent.TimeUnit



class Prueba2:Serializable {
    var ok:String? = null
    var token:String? =null
}

class ApiDataSource(private val userService: UserService,
                    private val outUserEntityMapper: OutUserEntityMapper,
                    private val outAppUserMapper: OutAppUserMapper,
                    private val outAppCreateUserMapper: OutAppCreateUserMapper
): DataSource {

    override fun getUserTokenPrueba() {
        val Result = Observable.just( userService.getUserTokenPrueba("prueba4@armando.com", "1234aaaA"))
        println("#################  RESULT  #######################")
        println(Result)
        println("#################  RESULT  #######################")
    }


    override fun createUser(): Single<AppCreateUser> =
        userService.createUser("prueba4@armando.com", "1234aaaA", "Armando", "Fdez")
            .map { it.results }
            .map{
                outAppCreateUserMapper.transform(it)
            }



    override fun getUserToken(): Observable<AppUser> =
        userService.loginUser("anisgaro.gr@gmail.com", "1234aaaA")
            .map { it.results }
            .map { outAppUserMapper.transform(it) }

    override fun getUserList(): Flowable<List<UserEntity>> =
        Inject.userService.getUsers().map {
            it.results
        }
            .map { Inject.outUserEntityMapper.transformList(it) }
            .delay(2,TimeUnit.SECONDS)
}





